"""Train one MAPPO run.

CLI (Hydra):   python train.py comm=gated penalties.lambda_c=0.05 seed=1
Programmatic:  from train import run_training; run_training(cfg)
"""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import hydra
import jax
import numpy as np
from omegaconf import DictConfig, OmegaConf

from core.mappo import init_train_state, make_update
from core.setup import make_setup
from core.utils import git_hash, peak_memory_mb, save_checkpoint, seed_everything
from models.gates import lambda_schedule


def _maybe_wandb(cfg: DictConfig):
    if not cfg.logging.wandb:
        return None
    try:
        import wandb

        run = wandb.init(
            project=cfg.logging.wandb_project,
            mode=cfg.logging.wandb_mode,
            name=f"{cfg.exp_name}/{cfg.run_name}/seed_{cfg.seed}",
            config=OmegaConf.to_container(cfg, resolve=True),
            dir=str(Path(cfg.out_dir)),
        )
        run.config.update({"git_hash": git_hash()}, allow_val_change=True)
        return run
    except Exception as e:  # never let logging kill a training run
        print(f"[train] wandb disabled: {e}")
        return None


def run_training(cfg: DictConfig, verbose: bool = True) -> Path:
    out_dir = Path(cfg.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    OmegaConf.save(cfg, out_dir / "config.yaml", resolve=True)
    key = seed_everything(int(cfg.seed))
    setup = make_setup(cfg)
    k_init, key = jax.random.split(key)
    ts = init_train_state(setup, cfg, k_init)
    update = jax.jit(make_update(setup, cfg))
    wb = _maybe_wandb(cfg)

    total = int(cfg.algo.total_updates)
    P = cfg.penalties
    steps_per_update = int(cfg.algo.num_envs) * setup.env.max_steps
    rows = []
    t_start = time.time()
    t_compiled = None
    for u in range(total):
        progress = u / max(total, 1)
        lam_c = float(lambda_schedule(progress, P.lambda_c, P.warmup_frac, P.anneal_frac))
        lam_s = float(lambda_schedule(progress, P.lambda_s, P.warmup_frac, P.anneal_frac))
        key, k = jax.random.split(key)
        ts, metrics = update(ts, k, lam_c, lam_s)
        if u == 0:
            jax.block_until_ready(metrics)
            t_compiled = time.time()
        if u % int(cfg.logging.log_every) == 0 or u == total - 1:
            m = {k_: float(v) for k_, v in jax.device_get(metrics).items()}
            elapsed = time.time() - (t_compiled or t_start)
            m.update(update=u, env_steps=(u + 1) * steps_per_update,
                     fps=(u * steps_per_update / elapsed) if u > 0 and elapsed > 0 else float("nan"))
            rows.append(m)
            if verbose:
                print(f"[{cfg.run_name} s{cfg.seed}] upd {u:5d} ret {m['episode_return']:8.3f} "
                      f"succ {m['success_rate']:.2f} links {m['active_link_ratio']:.2f} "
                      f"sw {m['gate_switch_rate']:.3f} lc {lam_c:.3g} ls {lam_s:.3g}", flush=True)
            if wb is not None:
                wb.log(m, step=u)

    wall = time.time() - t_start
    run_time = time.time() - (t_compiled or t_start)
    fps = (total - 1) * steps_per_update / run_time if total > 1 and run_time > 0 else float("nan")
    extra = dict(wall_time_s=wall, fps_env_steps=fps, fps_agent_steps=fps * setup.env.n_agents,
                 peak_memory_mb=peak_memory_mb(), final_metrics=rows[-1] if rows else {})
    save_checkpoint(out_dir, ts.params, cfg, extra)
    if rows:
        with open(out_dir / "train_metrics.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    if wb is not None:
        wb.summary.update({k_: v for k_, v in extra.items() if isinstance(v, (int, float))})
        wb.finish()
    if verbose:
        print(f"[train] saved {out_dir}  ({wall:.0f}s, {fps:.0f} env-steps/s)\n{json.dumps(extra['final_metrics'], default=float)}")
    return out_dir


@hydra.main(version_base="1.3", config_path="configs", config_name="config")
def main(cfg: DictConfig) -> None:
    np.set_printoptions(precision=4)
    run_training(cfg)


if __name__ == "__main__":
    main()
